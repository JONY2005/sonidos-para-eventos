# Setup Paso a Paso: GitHub + Codespaces + Vercel

## Contexto

Tienes 5 archivos listos en `/mnt/user-data/outputs/dashboard-db-eventos-repo/`:
- `index.html` — el dashboard completo (sin dependencias)
- `package.json` — metadatos del proyecto
- `README.md` — documentación
- `.gitignore` — archivos a ignorar en Git
- `vercel.json` — config para Vercel

## PASO 1: Crear el repo en GitHub (2 min)

1. Ve a https://github.com/new en Safari de tu iPad
2. Nombre: **dashboard-db-eventos**
3. Descripción: "Dashboard gerencial para eventos — Res. 627/2006 + SAYCO/ACINPRO"
4. Privado o público (tu elección)
5. Botón **"Create repository"**
6. Copia la URL que te da (tipo `https://github.com/JONY2005/dashboard-db-eventos.git`)

## PASO 2: Abrir Codespaces (1 min)

En el repo que acabas de crear:
1. Botón verde **"<> Code"**
2. Pestaña **"Codespaces"**
3. **"Create codespace on main"** — espera unos 30 segundos a que cargue
4. Se abre el editor en tu navegador (como siempre con ATE)

## PASO 3: Copiar los archivos (3 min)

Tienes dos opciones:

### Opción A (recomendada): Desde Codespaces directo
1. En el terminal de Codespaces (abajo de la pantalla):
   ```bash
   # Si no estás en la carpeta raíz del repo:
   cd /workspaces/dashboard-db-eventos
   
   # Copia los archivos desde uploads (donde los dejé preparados):
   # Nota: En Codespaces no tienes acceso directo a /mnt/user-data
   # Así que mejor sigas la Opción B
   ```

### Opción B (más directa): Desde tu iPad
1. Descarga desde este chat todos los archivos (o pídeme que te los pase como .zip):
   - `index.html`
   - `package.json`
   - `README.md`
   - `.gitignore`
   - `vercel.json`

2. En Codespaces, botón de upload (o arrastra los archivos) → sube cada uno a la raíz del repo

3. Verifica que estén todos:
   ```bash
   ls -la
   # Deberías ver: index.html, package.json, README.md, .gitignore, vercel.json
   ```

## PASO 4: Git commit y push (1 min)

En el terminal de Codespaces:

```bash
# Agrega todos los archivos
git add .

# Commit con mensaje
git commit -m "initial: dashboard v4.0 con Res. 627, clasificador, salud, SAYCO/ACINPRO"

# Push a main
git push origin main
```

## PASO 5: Conectar Vercel (5 min)

### Si ya tienes un proyecto Vercel conectado a GitHub (como ATE):

1. Ve a https://vercel.com/dashboard en Safari
2. Botón **"Add New..."** → **"Project"**
3. Selecciona el repo `dashboard-db-eventos` de tu GitHub
4. Vercel detecta que es un sitio estático HTML → no necesita build
5. **"Deploy"** → espera 1–2 minutos
6. Te da la URL: `https://dashboard-db-eventos.vercel.app`

### Si no tienes Vercel conectado a GitHub todavía:

1. Ve a https://vercel.com en Safari
2. Sign up / Log in con tu cuenta GitHub
3. Conecta tu GitHub → autoriza Vercel
4. Luego sigue los pasos del punto anterior

## PASO 6: Verifica que esté live (1 min)

1. Copia el URL que te da Vercel: `https://dashboard-db-eventos.vercel.app`
2. Ábrelo en Safari de tu iPad
3. Deberías ver el dashboard completo, con los 6 tabs, colores, funcional
4. Prueba ingresando datos — se guardan en localStorage (sin internet)

## ¿Ya está? ✅

Listo — ahora tienes:
- ✅ Repo en GitHub (`dashboard-db-eventos`)
- ✅ Deployado en Vercel con URL en vivo
- ✅ Accesible desde tu iPad sin internet (después de la primera carga)
- ✅ Codespaces listo para futuros cambios

## Para futuras ediciones

Cuando quieras cambiar algo:
1. Abre Codespaces del repo
2. Edita `index.html` (o los archivos que necesites)
3. `git add . && git commit -m "descripción" && git push origin main`
4. Vercel auto-deploya en 30 segundos — ya está live

---

**¿Problemas?** Avísame en el siguiente chat qué paso falla, con screenshot si es posible.
