# Dashboard dB para Eventos · Comfama

Guía gerencial 100% offline para construir y ejecutar eventos: clasificación de complejidad, cumplimiento de ruido, sistema de sonido, salud, derechos de autor, sonómetro en vivo, base de insumos e input list. **No es una herramienta contable** — no maneja presupuestos ni cifras de costo, salvo los valores legales de SAYCO/ACINPRO que sí son un monto a pagar.

**Marco normativo integrado:**
- Resolución 627 de 2006 (MAVDT) — estándares de ruido
- Guía Técnica Alcaldía de Medellín 2018 — recurso prehospitalario
- Ley 23/1982 + Decreto 3942/2010 — derechos de autor (SAYCO/ACINPRO)

## Versión Actual

**v6.0.0** — HTML standalone, sin dependencias externas, funciona offline.

### Ajustes de esta versión (v6.0)

1. ✅ **Salud — APH Simplificado**: para eventos académicos/de baja relevancia, nueva opción junto a la tabla oficial: "1 Auxiliar APH + botiquín de primeros auxilios", con aviso de que requiere autorización de la Secretaría de Salud. No reemplaza la tabla oficial, es un complemento visible solo para tipo de evento "Académico".
2. ✅ **Sonómetro vinculado a toda la app**: mientras está midiendo, aparece una insignia con el dB en vivo en el encabezado — visible en cualquier pestaña, no solo en Sonómetro. Podés seguir trabajando en Evento, Salud o Insumos con la medición corriendo de fondo.
3. ✅ **Tomar muestras**: nuevo botón "📍 Tomar muestra" que guarda una lectura puntual con hora, comparada contra el límite normativo del sector. Quedan en una lista con promedio, máximo y cuántas superaron el límite.
4. ✅ **El consolidado del evento ahora incluye el sonómetro**: cantidad de muestras, promedio, máximo y excedidas — visible en la tarjeta expandible de Ejecutivo y en ambos CSV.

### Ajustes de esta versión (v5.9) — Consolidación entre pestañas

Al guardar un evento en el banco de ejecución, ahora se arma un **macro consolidado real** trayendo información calculada en cada pestaña, no solo lo que se ve en Evento:

1. ✅ **Salud**: equipos de avanzada, PAS-B, PAS-M, ambulancias TAB/TAM y baños requeridos, calculados con el mismo aforo/tipo de evento.
2. ✅ **Checklist IVC**: cuántos ítems quedaron marcados al momento de guardar (ej. "6/9").
3. ✅ **Derechos de autor**: valores de SAYCO, ACINPRO y el total, tomados de la pestaña Evento.
4. ✅ **Input List**: cantidad de agrupaciones, canales totales, mezclas de monitor y la consola recomendada — todo lo que armaste en esa pestaña.
5. ✅ **Insumos** seleccionados (ya venía de antes).
6. ✅ Cada evento guardado en Ejecutivo ahora es **expandible** (tocá la tarjeta) para ver todo el consolidado sin salir de la pestaña.
7. ✅ El CSV individual y el consolidado general ahora traen todas estas columnas nuevas.

### Ajustes de esta versión (v5.8) — revisión de Insumos / Ejecutivo / Salud

Auditoría completa con tests automáticos de las tres pestañas (sin bugs de funcionamiento — todo probado: abrir categorías de insumos, agregar/quitar, buscador, sincronización de aforo, checklist IVC, estadísticas del banco).

1. ✅ **Nuevo aviso en Salud**: la clasificación "Compleja/No compleja" era 100% manual, independiente del clasificador automático de Evento (que calcula Alta/Mediana/Baja según aforo, impacto y si altera la ciudad). Si quedaban desalineados, el recurso prehospitalario sugerido podía quedar corto. Ahora Salud compara ambos y avisa si no coinciden, sin sobreescribir tu elección manual.

### Ajustes de esta versión (v5.7)

1. ✅ **Micrófonos inalámbricos en voz y coros**: Voz Principal ahora sugiere KSM9HS Inalámbrico y Beta 58A Inalámbrico junto a las opciones con cable. Coro suma SM58 Inalámbrico.
2. ✅ **Presentador/Talkback con opciones inalámbricas reales**: SM58 Inalámbrico, Diadema inalámbrica (headset) y Solapa inalámbrica (lavalier) — las opciones típicas para un maestro de ceremonias que camina por el escenario.
3. ✅ **Agregado "Presentador / Maestro de Ceremonias"** a la lista de instrumentos/canales — antes solo existía como palabra clave de sugerencia, no como opción seleccionable.
4. ✅ **Listado de instrumentos ordenado alfabéticamente** (con criterio de idioma español, ñ y tildes en su lugar) — se ordena automáticamente sin importar cómo se agreguen internamente.

### Ajustes de esta versión (v5.6) — Instrumentos compuestos desglosados

Analicé qué instrumentos de la lista en realidad son un **set de varias piezas**, cada una con micrófono propio, y las desglosé:

1. ✅ **Congas** (tu ejemplo): ahora son 3 opciones separadas — Conga - Quinto, Conga - Tres Golpes, Conga - Tumba — más "Congas (set, 1-2 mics)" para setups más simples que no quieren desglosar.
2. ✅ **Timbales**: desglosados en Timbal Alto (Macho) y Timbal Bajo (Hembra) — normalmente son 2 tambores, cada uno con su propio mic.
3. ✅ **Piano acústico**: desglosado en Piano Acústico Grave y Piano Acústico Agudo — un piano de cola profesional casi siempre se mic'ea en 2 canales (graves/agudos), no en uno solo.
4. ✅ **Cajón flamenco**: agregada la opción de desglosarlo en Grave (interior) y Agudo (frontal) para setups que lo mic'ean doble, además de la opción simple de un solo mic.
5. ✅ **Batería electrónica**: agregada la opción de salida estéreo (Izq/Der) además de la mono.
6. ✅ **Campana / Cencerro**: separada como su propio ítem (antes estaba mezclada con güiro/maracas).
7. ✅ Corregido un bug de orden de coincidencias: "Timbal Bajo" se sugería mal (tomaba el mic de Bajo eléctrico) porque la palabra "bajo" se cruzaba con el instrumento Bajo — reordenado para que las coincidencias específicas de percusión se evalúen antes que las genéricas.

### Ajustes de esta versión (v5.5)

1. ✅ **Descartado el punto "Zona en el escenario"** (y el stage plot automático que generaba) — vuelve el formato simple de canal + instrumento + mic/DI + stage box + notas.
2. ✅ **Aclarado qué es "Stage box / cable"**: es el número del snake/multicore donde va físicamente ese canal en el escenario (ej. "A1" = entrada A del stage box 1) — ahora tiene una explicación visible en la app.
3. ✅ **Corregido el PDF que no se veía ni se podía descargar**: el botón "Vista de impresión" abría una ventana nueva con `window.open()`, que muchos navegadores (sobre todo en tablet/iPad) bloquean como pop-up sin avisar claramente. Ahora usa un iframe oculto en la misma página — no depende del bloqueador de pop-ups.
4. ✅ **Nuevo botón "Descargar documento"**: como respaldo si el diálogo de impresión no abre solo, descarga el mismo documento como archivo `.html` que se puede abrir aparte y guardar como PDF desde ahí (Ctrl/Cmd+P → Guardar como PDF).

### Ajustes de esta versión (v5.4)

1. ✅ **Corregidas las tildes/ñ rotas en el CSV** ("AgrupaciÃ³n" en vez de "Agrupación"): la causa era la directiva `sep=;` que agregué en la v5.3 para forzar el separador — esa directiva hace que Excel ignore el BOM UTF-8 y lea todo como ANSI. La quité; con el BOM solo + `;` alcanza para Excel en español y ahora respeta los acentos.
2. ✅ **Nuevo: Stage Plot automático.** Analizado a partir de tu ejemplo (banda "Todos los Perros") y las referencias TecRider / LSV Rider Técnico. Cada canal ahora tiene un campo **"Zona en el escenario"** (grilla estándar de 9 zonas: USL/USC/USR — CSL/CSC/CSR — DSL/DSC/DSR — más "Monitor World"). La vista de impresión genera automáticamente un diagrama del escenario con los números de canal ubicados en su zona, arriba de la tabla de cada agrupación — igual al formato de diagrama + tabla de tu ejemplo.
3. ✅ El campo que antes era "Posición / Stage box" ahora es solo para el número de stage box/cable (ej. "A1", "C4"), separado de la zona.
4. ✅ CSV y tabla de impresión actualizados con la nueva columna "Zona".

### Ajustes de esta versión (v5.3)

1. ✅ **Corregido el CSV que se veía todo en una sola columna al abrirlo en Excel**: el problema era el separador — Excel en español (Colombia/Latam) usa `;` para columnas porque reserva la `,` como separador decimal. Ahora el CSV usa `;` y agrega una directiva `sep=;` que fuerza el separador correcto sin importar la configuración regional del equipo.
2. ✅ **Tabla de micrófonos ampliada** con investigación adicional (Sweetwater, ProSoundWeb, riders profesionales de percusión latina y vientos), no solo el input list que compartiste — ahora cubre batería completa, percusión latina (congas, bongó, timbal, cajón), cuerdas (violín, viola, cello, arpa), vientos (saxofón, trompeta, trombón, flauta, clarinete) y líneas de DJ/playback.
3. ✅ **Listado de instrumentos ampliado** en el autocompletado, con las mismas categorías nuevas.

### Ajustes de esta versión (v5.2) — Input List profesional multi-agrupación

1. ✅ **Input List rediseñada** tras analizar TecRider y LSV Rider Técnico: ahora soporta **varias agrupaciones** en el mismo evento (bandas, solistas, coros, DJs, etc.), cada una con su propio set de canales.
2. ✅ Cada agrupación registra **cantidad de integrantes por género** (hombres/mujeres/otro) y **tipo de agrupación**, para análisis posterior.
3. ✅ Cada agrupación define su **tipo de monitoreo** (wedges/in-ears/mixto) y **mezclas de monitor necesarias**.
4. ✅ Nuevo **resumen automático**: canales totales, mezclas de monitor totales, y **consola recomendada** según el total de canales de todas las agrupaciones.
5. ✅ Nueva **vista de impresión / PDF**: genera un documento formateado (header del evento, tabla por agrupación, resumen de consola) — abrí "Vista de impresión" y guardá como PDF desde el diálogo de impresión del navegador. Esto reemplaza el CSV plano como entregable principal, aunque el CSV sigue disponible.
6. ✅ Datos del evento para el documento: nombre, lugar, fecha, contacto/responsable técnico.

### Ajustes de esta versión (v5.1) tras la primera ronda de pruebas

1. ✅ **Insumos**: base de datos reemplazada por la real — 845 ítems únicos extraídos y depurados de tu tarifario (antes solo había ~40 de ejemplo). Se agregó buscador en tiempo real.
2. ✅ Corregido un bug de HTML inválido (botón dentro de botón) que interfería con el clic de "agregar insumo".
3. ✅ **Evento**: nuevo selector de "Línea artística" (Música, Teatro, Danza, Artes plásticas, Literatura, Cine, Formación, Recreación, Ferias, Otro), registrado en el banco de ejecución y en las estadísticas del Ejecutivo.
4. ✅ Aclarado el punto "Estándar" (Emisión vs. Ambiental) con una explicación corta en pantalla.
5. ✅ **Sonómetro**: ahora detecta y avisa explícitamente cuando el micrófono no está disponible (típicamente al abrir el archivo directo sin https), en vez de fallar en silencio. Mejor manejo de errores de permisos.
6. ✅ **Corregido bug de foco**: escribir en el nombre del evento (y en cualquier campo de texto de la app) ya no se cortaba a cada tecla — el re-render ahora preserva dónde estabas escribiendo.
7. ✅ **Input List**: autocompletado de instrumentos + selector de 3 mics/DI sugeridos por instrumento (con opción "Otro" para escribir libre), basado en tu formato de ejemplo y estándares de sonido en vivo.

### Novedades de esta versión

1. ✅ Eliminadas todas las cifras de costo/inversión que no aplican (la app no es de presupuesto)
2. ✅ Sonómetro en vivo con el micrófono del dispositivo
3. ✅ Persistencia real por evento + **banco de ejecución** con estadísticas globales
4. ✅ Exportación de consolidado individual y general (CSV)
5. ✅ Aforo y hora del evento en 0 por defecto, con steppers y chips de selección rápida
6. ✅ Corregido el contraste del dropdown de sector/subsector (texto ilegible)
7. ✅ Sistema de sonido: podés desmarcar componentes que no necesitás
8. ✅ Fórmula de potencia RMS corregida con referencia técnica real (2–8 W RMS/persona según espacio y tipo de evento), con tooltip explicando qué es RMS
9. ✅ Salud: selector de tipo de actividad (académico/conferencia vs. musical/masivo)
10. ✅ Pestaña "Categoría" reemplazada por **Insumos**: base de datos de producción sin precios
11. ✅ Pestaña "Comparar" eliminada
12. ✅ Nueva pestaña **Input List** para armar la lista de canales de una presentación

### Pendiente de verificar

- El módulo SAYCO (tarifa general sin cobro de entrada) usa una fórmula por bloques de 500 personas heredada de la versión anterior. Quedó marcada en el código con una nota de advertencia (`sayco.verificar`) porque no se pudo re-confirmar contra el documento tarifario oficial en esta sesión — conviene revisarla contra el PDF de SAYCO antes de usarla como cifra definitiva.
- El sonómetro da una lectura **relativa** al micrófono del dispositivo (no calibrada), útil para tendencia durante el evento, no como reemplazo de un sonómetro certificado.

## Acceso

**Local (offline):**
- Descarga `index.html` y ábrelo en cualquier navegador.
- Los datos (eventos guardados, insumos, checklist, input list) se guardan en `localStorage` del dispositivo.
- El sonómetro necesita conexión seguro (https) o `localhost` — en `file://` el navegador puede bloquear el micrófono.

**En línea (Vercel):**
- URL: `https://dashboard-db-eventos.vercel.app`
- Auto-deploy con cada push a main.

## Estructura del Proyecto

```
dashboard-db-eventos/
├── index.html          # Dashboard completo (HTML + CSS + JS en un archivo)
├── package.json        # Metadatos del proyecto
├── .gitignore           # Archivos a ignorar en Git
├── vercel.json          # Configuración de deploy a Vercel
└── README.md            # Este archivo
```

## Setup en Codespaces (desde tu iPad)

1. **Crea el repo en GitHub**: https://github.com/new → nombre `dashboard-db-eventos` → Create repository.
2. **Abre Codespaces**: botón verde "<> Code" → "Codespaces" → "Create codespace on main".
3. **Sube estos archivos** a la raíz del repo (arrastralos o usá el botón de upload en Codespaces).
4. **Commit y push** en la terminal de Codespaces:
   ```bash
   git add .
   git commit -m "v5.0.0: sin costos, sonometro, banco de ejecucion, insumos, input list"
   git push origin main
   ```
5. **Conecta o verifica Vercel**: si ya tenés el proyecto conectado (como con ATE), el deploy es automático. Si no, entrá a vercel.com → Add New → Project → seleccioná el repo.

## Persistencia de Datos

Todo se guarda automáticamente en `localStorage` bajo la clave `dbeventos_state_v5`:
- Evento en curso (aforo, sector, hora, tipo de evento, insumos seleccionados, input list).
- **Banco de ejecución**: cada evento que guardás con el botón "Guardar evento en el banco" queda en un historial permanente, visible en la pestaña Ejecutivo, exportable en CSV.
- Persiste aunque cierres la app — solo en ese dispositivo. Para limpiar: DevTools (F12) → Application → Local Storage → delete.

## Licencia

MIT — úsalo libremente, en eventos de Comfama o en otros contextos.

---

**Última actualización**: Agosto 2026
**Versión**: 5.0.0 · Offline · Res. 627/2006 + SAYCO/ACINPRO
